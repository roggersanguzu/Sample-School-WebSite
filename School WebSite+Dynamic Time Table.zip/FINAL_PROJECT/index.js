const express = require("express");
const fs = require("fs");
const path = require("path");
const timetableGenerator = require("./timetableGenerator");

const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(express.json());

// Route to serve the main page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});

// Route to generate timetable
app.get("/generate", (req, res) => {
  const timetable = timetableGenerator.generate();
  fs.writeFileSync("./timetable.json", JSON.stringify(timetable));
  res.json(timetable);
});

// Route to get current timetable
app.get("/timetable", (req, res) => {
  if (fs.existsSync("./timetable.json")) {
    const timetable = JSON.parse(fs.readFileSync("./timetable.json"));
    res.json(timetable);
  } else {
    res.json(timetableGenerator.generate());
  }
});

// Route to save edited timetable
app.post("/save", (req, res) => {
  const timetable = req.body;
  if (timetableGenerator.validateConstraints(timetable)) {
    fs.writeFileSync("./timetable.json", JSON.stringify(timetable));
    res.json({ success: true });
  } else {
    res
      .status(400)
      .json({ success: false, message: "Timetable violates constraints" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
